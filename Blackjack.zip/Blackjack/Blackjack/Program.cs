﻿using System;
using System.Collections.Generic;

namespace Blackjack
{

    class Card
    {
        public string name;
        public int value;
        public string suit;

        public static void DisplayCard(Card card)
        {
            Console.WriteLine($"The {card.name} of {card.suit} with a value of: {card.value}");
        }
    }

    class RandomNumberMethod
    {
        private static Random r = new Random();
        public static int RMethod(int DeckOfCards)
        {
            return r.Next(DeckOfCards);
        }  
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Card> DeckOfCards = new List<Card>()
            {
                new Card() {name = "Ace", suit = "Spades", value = 11},
                new Card() {name = "Two", suit = "Spades", value = 2},
                new Card() {name = "Three", suit = "Spades", value = 3},
                new Card() {name = "Four", suit = "Spades", value = 4},
                new Card() {name = "Five", suit = "Spades", value = 5},
                new Card() {name = "Six", suit = "Spades", value = 6},
                new Card() {name = "Seven", suit = "Spades", value = 7},
                new Card() {name = "Eight", suit = "Spades", value = 8},
                new Card() {name = "Nine", suit = "Spades", value = 9},
                new Card() {name = "Ten", suit = "Spades", value = 10},
                new Card() {name = "Jack", suit = "Spades", value = 10},
                new Card() {name = "Queen", suit = "Spades", value = 10},
                new Card() {name = "King", suit = "Spades", value = 10},
                new Card() {name = "Ace", suit = "Clubs", value = 11},
                new Card() {name = "Two", suit = "Clubs", value = 2},
                new Card() {name = "Three", suit = "Clubs", value = 3},
                new Card() {name = "Four", suit = "Clubs", value = 4},
                new Card() {name = "Five", suit = "Clubs", value = 5},
                new Card() {name = "Six", suit = "Clubs", value = 6},
                new Card() {name = "Seven", suit = "Clubs", value = 7},
                new Card() {name = "Eight", suit = "Clubs", value = 8},
                new Card() {name = "Nine", suit = "Clubs", value = 9},
                new Card() {name = "Ten", suit = "Clubs", value = 10},
                new Card() {name = "Jack", suit = "Clubs", value = 10},
                new Card() {name = "Queen", suit = "Clubs", value = 10},
                new Card() {name = "King", suit = "Clubs", value = 10},
                new Card() {name = "Ace", suit = "Diamonds", value = 11},
                new Card() {name = "Two", suit = "Diamonds", value = 2},
                new Card() {name = "Three", suit = "Diamonds", value = 3},
                new Card() {name = "Four", suit = "Diamonds", value = 4},
                new Card() {name = "Five", suit = "Diamonds", value = 5},
                new Card() {name = "Six", suit = "Diamonds", value = 6},
                new Card() {name = "Seven", suit = "Diamonds", value = 7},
                new Card() {name = "Eight", suit = "Diamonds", value = 8},
                new Card() {name = "Nine", suit = "Diamonds", value = 9},
                new Card() {name = "Ten", suit = "Diamonds", value = 10},
                new Card() {name = "Jack", suit = "Diamonds", value = 10},
                new Card() {name = "Queen", suit = "Diamonds", value = 10},
                new Card() {name = "King", suit = "Diamonds", value = 10},
                new Card() {name = "Ace", suit = "Hearts", value = 11},
                new Card() {name = "Two", suit = "Hearts", value = 2},
                new Card() {name = "Three", suit = "Hearts", value = 3},
                new Card() {name = "Four", suit = "Hearts", value = 4},
                new Card() {name = "Five", suit = "Hearts", value = 5},
                new Card() {name = "Six", suit = "Hearts", value = 6},
                new Card() {name = "Seven", suit = "Hearts", value = 7},
                new Card() {name = "Eight", suit = "Hearts", value = 8},
                new Card() {name = "Nine", suit = "Hearts", value = 9},
                new Card() {name = "Ten", suit = "Hearts", value = 10},
                new Card() {name = "Jack", suit = "Hearts", value = 10},
                new Card() {name = "Queen", suit = "Hearts", value = 10},
                new Card() {name = "King", suit = "Hearts", value = 10},
            };

            List<Card> PlayerHands = new List<Card>();
            List<Card> DealerHands = new List<Card>();

            Console.WriteLine("You were delt:");

            Card pcard1 = DeckOfCards[RandomNumberMethod.RMethod(DeckOfCards.Count)];  //select card at random from deck and save it to a card

            PlayerHands.Add(pcard1);       //add card to players hand
            Card.DisplayCard(pcard1);      //display card 
            DeckOfCards.Remove(pcard1);    //remove card from deck so it cannot repeat

            Card dcard1 = DeckOfCards[RandomNumberMethod.RMethod(DeckOfCards.Count)];

            DealerHands.Add(dcard1);
            DeckOfCards.Remove(dcard1);

            Card pcard2 = DeckOfCards[RandomNumberMethod.RMethod(DeckOfCards.Count)];

            PlayerHands.Add(pcard2);
            Card.DisplayCard(pcard2);
            DeckOfCards.Remove(pcard2);

            Card dcard2 = DeckOfCards[RandomNumberMethod.RMethod(DeckOfCards.Count)];

            DealerHands.Add(dcard2);
            DeckOfCards.Remove(dcard2);

            int psum = 0;
            foreach (Card PlayerHand in PlayerHands)       //adding all the values of cards in a players hand for a sum
            {
                psum += PlayerHand.value;
            }

            int dsum = 0;
            foreach (Card DealerHand in DealerHands)
            {
                dsum += DealerHand.value;
            }

            if (psum == 21)
            {
                if (psum == dsum)
                {
                    Console.WriteLine("The Dealer reveals:");
                    Card.DisplayCard(dcard1);
                    Card.DisplayCard(dcard2);
                    Console.WriteLine("The Player and Dealer end in a tie. The game is a push. Press Enter.");
                    Console.ReadLine();
                }

                else if (psum != dsum)
                {
                    Console.WriteLine("The Dealer reveals:");
                    Card.DisplayCard(dcard1);
                    Card.DisplayCard(dcard2);
                    Console.WriteLine("Player beats the Dealer. You win. Game over. Press Enter.");
                    Console.ReadLine();
                    
                }
            }

            else
            {
                Console.WriteLine($"The sum of the Players cards is: {psum}. Press Enter.");
                Console.ReadLine();

                Console.WriteLine("The dealer is showing:");
                Card.DisplayCard(dcard2);
                Console.WriteLine("Press Enter.");
                Console.ReadLine();



                bool hit = true;
                while (hit == true)
                {
                    Console.WriteLine("Would you like to Hit or Stay? Type Hit or Stay please.");
                    string hitStay = Console.ReadLine().ToLower();

                    if (hitStay == "hit")
                    {
                        Card pcard = DeckOfCards[RandomNumberMethod.RMethod(DeckOfCards.Count)];

                        PlayerHands.Add(pcard);
                        Card.DisplayCard(pcard);
                        DeckOfCards.Remove(pcard);

                        psum = 0;

                        

                        foreach (Card PlayerHand in PlayerHands)
                        {
                            psum += PlayerHand.value;
                        }
                        
                        PlayerHands = CheckPlayerAce(PlayerHands);

                        psum = 0;

                        foreach (Card PlayerHand in PlayerHands)
                        {
                            psum += PlayerHand.value;
                        }

                        Console.WriteLine($"Your new sum is: {psum}.");

                        if (psum > 21)
                        {
                            Console.WriteLine("Player bust. You lose. Game over. Press Enter.");
                            hit = false;
                        }
                    }
                    

                    else if (hitStay == "stay")
                    {
                        hit = false;
                    }
                }

                while (psum <= 21)
                {
                    Console.WriteLine("The Dealer reveals:");
                    Card.DisplayCard(dcard1);
                    Console.WriteLine($"The sum of the Dealers cards is {dsum}. Press Enter.");
                    Console.ReadLine();

                    while (dsum < 15)
                    {
                        Console.WriteLine("Dealer required to hit. Reveals:");

                        Card dcard = DeckOfCards[RandomNumberMethod.RMethod(DeckOfCards.Count)];

                        DealerHands.Add(dcard);
                        Card.DisplayCard(dcard);
                        DeckOfCards.Remove(dcard);

                        dsum = 0;

                        foreach (Card DealerHand in DealerHands)
                        {
                            dsum += DealerHand.value;
                        }
                        Console.WriteLine($"The Dealers new sum is: {dsum}. Press Enter");
                        Console.ReadLine();
                    }

                    
                        DealerHands = CheckDealerAce(hit, DealerHands);

                        dsum = 0;

                        foreach (Card DealerHand in DealerHands)
                        {
                        dsum += DealerHand.value;
                        }


                        if (dsum > 21)
                        {
                            Console.WriteLine("Dealer busts. You win. Game over. Press Enter.");
                        break;
                        }

                        else if (dsum < psum)
                        {
                            Console.WriteLine("Player beats the Dealer. You win. Game over. Press Enter.");
                            hit = false;
                            break;
                        }

                        else if (dsum > psum)
                        {
                            Console.WriteLine("Dealer beats the Player. You lose. Game over. Press Enter");
                            hit = false;
                            break;
                        }

                        else if (dsum == psum)
                        {
                            Console.WriteLine("The Player and Dealer end in a tie. The game is a push. Press Enter.");
                            hit = false;
                            break;
                        }
                    
                }
                Console.ReadLine();
            }



        }
        public static List<Card> CheckPlayerAce(List<Card> PlayerHands)
        {
            foreach (Card PlayerHand in PlayerHands)
            {
                if (PlayerHand.value == 11)
                {
                    PlayerHand.value = 1;
                    break;
                }
            }
            return PlayerHands;
        }

        public static List<Card> CheckDealerAce(bool hit, List<Card> DealerHands)
        {
            foreach (Card DealerHand in DealerHands)
            {
                if (DealerHand.value == 11)
                {
                    DealerHand.value = 1;
                    break;
                }
            }
            return DealerHands;
        }
    }
}
//In this version the cards go from 1-10 (there are no Aces, Kings, etc.).
//The objective of the game is to get 21
//You can continue to get cards as long as you are not over 21
//Go over 21, you lose.
//The dealer shows only 1 of their cards, their total will not be known until the game is finished.
//The dealer must keep getting cards if their number is lower then 15
//If you and the dealer have the same number, the game is a tie.