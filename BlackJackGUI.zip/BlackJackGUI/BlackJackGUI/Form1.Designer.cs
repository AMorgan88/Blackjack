﻿namespace BlackJackGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pcaPictureBox = new System.Windows.Forms.PictureBox();
            this.pcaLabel = new System.Windows.Forms.Label();
            this.pcaLabel2 = new System.Windows.Forms.Label();
            this.pcbPictureBox = new System.Windows.Forms.PictureBox();
            this.pcbLabel = new System.Windows.Forms.Label();
            this.pcbLabel2 = new System.Windows.Forms.Label();
            this.dcoPictureBox = new System.Windows.Forms.PictureBox();
            this.dcbPictureBox = new System.Windows.Forms.PictureBox();
            this.dcbLabel = new System.Windows.Forms.Label();
            this.dcbLabel2 = new System.Windows.Forms.Label();
            this.pccPictureBox = new System.Windows.Forms.PictureBox();
            this.pcdPictureBox = new System.Windows.Forms.PictureBox();
            this.pcePictureBox = new System.Windows.Forms.PictureBox();
            this.dccPictureBox = new System.Windows.Forms.PictureBox();
            this.dcdPictureBox = new System.Windows.Forms.PictureBox();
            this.dcePictureBox = new System.Windows.Forms.PictureBox();
            this.pcfPictureBox = new System.Windows.Forms.PictureBox();
            this.dcfPictureBox = new System.Windows.Forms.PictureBox();
            this.dccLabel = new System.Windows.Forms.Label();
            this.dccLabel2 = new System.Windows.Forms.Label();
            this.dcdLabel = new System.Windows.Forms.Label();
            this.dcdLabel2 = new System.Windows.Forms.Label();
            this.dceLabel = new System.Windows.Forms.Label();
            this.dceLabel2 = new System.Windows.Forms.Label();
            this.dcfLabel = new System.Windows.Forms.Label();
            this.dcfLabel2 = new System.Windows.Forms.Label();
            this.pccLabel = new System.Windows.Forms.Label();
            this.pccLabel2 = new System.Windows.Forms.Label();
            this.pcdLabel = new System.Windows.Forms.Label();
            this.pcdLabel2 = new System.Windows.Forms.Label();
            this.pceLabel = new System.Windows.Forms.Label();
            this.pceLabel2 = new System.Windows.Forms.Label();
            this.pcfLabel = new System.Windows.Forms.Label();
            this.pcfLabel2 = new System.Windows.Forms.Label();
            this.dcaPictureBox = new System.Windows.Forms.PictureBox();
            this.dcaLabel = new System.Windows.Forms.Label();
            this.dcaLabel2 = new System.Windows.Forms.Label();
            this.dealButton = new System.Windows.Forms.Button();
            this.hitButton = new System.Windows.Forms.Button();
            this.stayButton = new System.Windows.Forms.Button();
            this.displayTextLabel = new System.Windows.Forms.Label();
            this.continueButton = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pWinsLabel = new System.Windows.Forms.Label();
            this.dWinsLabel = new System.Windows.Forms.Label();
            this.winPercentLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dcgPictureBox = new System.Windows.Forms.PictureBox();
            this.dchPictureBox = new System.Windows.Forms.PictureBox();
            this.dciPictureBox = new System.Windows.Forms.PictureBox();
            this.dcjPictureBox = new System.Windows.Forms.PictureBox();
            this.dckPictureBox = new System.Windows.Forms.PictureBox();
            this.pcgPictureBox = new System.Windows.Forms.PictureBox();
            this.pchPictureBox = new System.Windows.Forms.PictureBox();
            this.pciPictureBox = new System.Windows.Forms.PictureBox();
            this.pcjPictureBox = new System.Windows.Forms.PictureBox();
            this.pckPictureBox = new System.Windows.Forms.PictureBox();
            this.dcgLabel = new System.Windows.Forms.Label();
            this.dchLabel = new System.Windows.Forms.Label();
            this.dciLabel = new System.Windows.Forms.Label();
            this.dcjLabel = new System.Windows.Forms.Label();
            this.dckLabel = new System.Windows.Forms.Label();
            this.pcgLabel = new System.Windows.Forms.Label();
            this.pchLabel = new System.Windows.Forms.Label();
            this.pciLabel = new System.Windows.Forms.Label();
            this.pcjLabel = new System.Windows.Forms.Label();
            this.pckLabel = new System.Windows.Forms.Label();
            this.dcgLabel2 = new System.Windows.Forms.Label();
            this.dchLabel2 = new System.Windows.Forms.Label();
            this.dciLabel2 = new System.Windows.Forms.Label();
            this.dcjLabel2 = new System.Windows.Forms.Label();
            this.dckLabel2 = new System.Windows.Forms.Label();
            this.pcgLabel2 = new System.Windows.Forms.Label();
            this.pchLabel2 = new System.Windows.Forms.Label();
            this.pciLabel2 = new System.Windows.Forms.Label();
            this.pcjLabel2 = new System.Windows.Forms.Label();
            this.pckLabel2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcaPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcbPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pccPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcdPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dccPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcdPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcfPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcfPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcaPictureBox)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcgPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dchPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dciPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcjPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dckPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcgPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pchPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pciPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcjPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pckPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 116);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pcaPictureBox
            // 
            this.pcaPictureBox.BackColor = System.Drawing.Color.White;
            this.pcaPictureBox.Location = new System.Drawing.Point(12, 241);
            this.pcaPictureBox.Name = "pcaPictureBox";
            this.pcaPictureBox.Size = new System.Drawing.Size(76, 115);
            this.pcaPictureBox.TabIndex = 1;
            this.pcaPictureBox.TabStop = false;
            this.pcaPictureBox.Visible = false;
            // 
            // pcaLabel
            // 
            this.pcaLabel.AutoSize = true;
            this.pcaLabel.BackColor = System.Drawing.Color.White;
            this.pcaLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcaLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pcaLabel.Location = new System.Drawing.Point(21, 251);
            this.pcaLabel.Name = "pcaLabel";
            this.pcaLabel.Size = new System.Drawing.Size(53, 26);
            this.pcaLabel.TabIndex = 2;
            this.pcaLabel.Text = "PCA";
            this.pcaLabel.Visible = false;
            // 
            // pcaLabel2
            // 
            this.pcaLabel2.AutoSize = true;
            this.pcaLabel2.BackColor = System.Drawing.Color.White;
            this.pcaLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pcaLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pcaLabel2.Location = new System.Drawing.Point(31, 287);
            this.pcaLabel2.Name = "pcaLabel2";
            this.pcaLabel2.Size = new System.Drawing.Size(105, 37);
            this.pcaLabel2.TabIndex = 3;
            this.pcaLabel2.Text = "PCA2";
            this.pcaLabel2.Visible = false;
            // 
            // pcbPictureBox
            // 
            this.pcbPictureBox.BackColor = System.Drawing.Color.White;
            this.pcbPictureBox.Location = new System.Drawing.Point(94, 241);
            this.pcbPictureBox.Name = "pcbPictureBox";
            this.pcbPictureBox.Size = new System.Drawing.Size(76, 115);
            this.pcbPictureBox.TabIndex = 4;
            this.pcbPictureBox.TabStop = false;
            this.pcbPictureBox.Visible = false;
            // 
            // pcbLabel
            // 
            this.pcbLabel.AutoSize = true;
            this.pcbLabel.BackColor = System.Drawing.Color.White;
            this.pcbLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcbLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pcbLabel.Location = new System.Drawing.Point(103, 251);
            this.pcbLabel.Name = "pcbLabel";
            this.pcbLabel.Size = new System.Drawing.Size(51, 26);
            this.pcbLabel.TabIndex = 5;
            this.pcbLabel.Text = "PCB";
            this.pcbLabel.Visible = false;
            // 
            // pcbLabel2
            // 
            this.pcbLabel2.AutoSize = true;
            this.pcbLabel2.BackColor = System.Drawing.Color.White;
            this.pcbLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pcbLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pcbLabel2.Location = new System.Drawing.Point(115, 287);
            this.pcbLabel2.Name = "pcbLabel2";
            this.pcbLabel2.Size = new System.Drawing.Size(104, 37);
            this.pcbLabel2.TabIndex = 6;
            this.pcbLabel2.Text = "PCB2";
            this.pcbLabel2.Visible = false;
            // 
            // dcoPictureBox
            // 
            this.dcoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("dcoPictureBox.Image")));
            this.dcoPictureBox.Location = new System.Drawing.Point(127, 38);
            this.dcoPictureBox.Name = "dcoPictureBox";
            this.dcoPictureBox.Size = new System.Drawing.Size(76, 116);
            this.dcoPictureBox.TabIndex = 7;
            this.dcoPictureBox.TabStop = false;
            this.dcoPictureBox.Visible = false;
            // 
            // dcbPictureBox
            // 
            this.dcbPictureBox.BackColor = System.Drawing.Color.White;
            this.dcbPictureBox.Location = new System.Drawing.Point(209, 37);
            this.dcbPictureBox.Name = "dcbPictureBox";
            this.dcbPictureBox.Size = new System.Drawing.Size(76, 117);
            this.dcbPictureBox.TabIndex = 10;
            this.dcbPictureBox.TabStop = false;
            this.dcbPictureBox.Visible = false;
            // 
            // dcbLabel
            // 
            this.dcbLabel.AutoSize = true;
            this.dcbLabel.BackColor = System.Drawing.Color.White;
            this.dcbLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcbLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dcbLabel.Location = new System.Drawing.Point(219, 47);
            this.dcbLabel.Name = "dcbLabel";
            this.dcbLabel.Size = new System.Drawing.Size(55, 26);
            this.dcbLabel.TabIndex = 11;
            this.dcbLabel.Text = "DCB";
            this.dcbLabel.Visible = false;
            // 
            // dcbLabel2
            // 
            this.dcbLabel2.AutoSize = true;
            this.dcbLabel2.BackColor = System.Drawing.Color.White;
            this.dcbLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.dcbLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dcbLabel2.Location = new System.Drawing.Point(226, 83);
            this.dcbLabel2.Name = "dcbLabel2";
            this.dcbLabel2.Size = new System.Drawing.Size(106, 37);
            this.dcbLabel2.TabIndex = 12;
            this.dcbLabel2.Text = "DCB2";
            this.dcbLabel2.Visible = false;
            // 
            // pccPictureBox
            // 
            this.pccPictureBox.BackColor = System.Drawing.Color.White;
            this.pccPictureBox.Location = new System.Drawing.Point(176, 241);
            this.pccPictureBox.Name = "pccPictureBox";
            this.pccPictureBox.Size = new System.Drawing.Size(73, 115);
            this.pccPictureBox.TabIndex = 13;
            this.pccPictureBox.TabStop = false;
            this.pccPictureBox.Visible = false;
            // 
            // pcdPictureBox
            // 
            this.pcdPictureBox.BackColor = System.Drawing.Color.White;
            this.pcdPictureBox.Location = new System.Drawing.Point(255, 241);
            this.pcdPictureBox.Name = "pcdPictureBox";
            this.pcdPictureBox.Size = new System.Drawing.Size(76, 115);
            this.pcdPictureBox.TabIndex = 14;
            this.pcdPictureBox.TabStop = false;
            this.pcdPictureBox.Visible = false;
            // 
            // pcePictureBox
            // 
            this.pcePictureBox.BackColor = System.Drawing.Color.White;
            this.pcePictureBox.Location = new System.Drawing.Point(337, 241);
            this.pcePictureBox.Name = "pcePictureBox";
            this.pcePictureBox.Size = new System.Drawing.Size(76, 115);
            this.pcePictureBox.TabIndex = 15;
            this.pcePictureBox.TabStop = false;
            this.pcePictureBox.Visible = false;
            // 
            // dccPictureBox
            // 
            this.dccPictureBox.BackColor = System.Drawing.Color.White;
            this.dccPictureBox.Location = new System.Drawing.Point(291, 37);
            this.dccPictureBox.Name = "dccPictureBox";
            this.dccPictureBox.Size = new System.Drawing.Size(76, 117);
            this.dccPictureBox.TabIndex = 16;
            this.dccPictureBox.TabStop = false;
            this.dccPictureBox.Visible = false;
            // 
            // dcdPictureBox
            // 
            this.dcdPictureBox.BackColor = System.Drawing.Color.White;
            this.dcdPictureBox.Location = new System.Drawing.Point(372, 37);
            this.dcdPictureBox.Name = "dcdPictureBox";
            this.dcdPictureBox.Size = new System.Drawing.Size(76, 117);
            this.dcdPictureBox.TabIndex = 17;
            this.dcdPictureBox.TabStop = false;
            this.dcdPictureBox.Visible = false;
            // 
            // dcePictureBox
            // 
            this.dcePictureBox.BackColor = System.Drawing.Color.White;
            this.dcePictureBox.Location = new System.Drawing.Point(454, 38);
            this.dcePictureBox.Name = "dcePictureBox";
            this.dcePictureBox.Size = new System.Drawing.Size(76, 116);
            this.dcePictureBox.TabIndex = 18;
            this.dcePictureBox.TabStop = false;
            this.dcePictureBox.Visible = false;
            // 
            // pcfPictureBox
            // 
            this.pcfPictureBox.BackColor = System.Drawing.Color.White;
            this.pcfPictureBox.Location = new System.Drawing.Point(419, 241);
            this.pcfPictureBox.Name = "pcfPictureBox";
            this.pcfPictureBox.Size = new System.Drawing.Size(76, 115);
            this.pcfPictureBox.TabIndex = 19;
            this.pcfPictureBox.TabStop = false;
            this.pcfPictureBox.Visible = false;
            // 
            // dcfPictureBox
            // 
            this.dcfPictureBox.BackColor = System.Drawing.Color.White;
            this.dcfPictureBox.Location = new System.Drawing.Point(536, 37);
            this.dcfPictureBox.Name = "dcfPictureBox";
            this.dcfPictureBox.Size = new System.Drawing.Size(77, 117);
            this.dcfPictureBox.TabIndex = 20;
            this.dcfPictureBox.TabStop = false;
            this.dcfPictureBox.Visible = false;
            // 
            // dccLabel
            // 
            this.dccLabel.AutoSize = true;
            this.dccLabel.BackColor = System.Drawing.Color.White;
            this.dccLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dccLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dccLabel.Location = new System.Drawing.Point(300, 47);
            this.dccLabel.Name = "dccLabel";
            this.dccLabel.Size = new System.Drawing.Size(56, 26);
            this.dccLabel.TabIndex = 21;
            this.dccLabel.Text = "DCC";
            this.dccLabel.Visible = false;
            // 
            // dccLabel2
            // 
            this.dccLabel2.AutoSize = true;
            this.dccLabel2.BackColor = System.Drawing.Color.White;
            this.dccLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.dccLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dccLabel2.Location = new System.Drawing.Point(310, 83);
            this.dccLabel2.Name = "dccLabel2";
            this.dccLabel2.Size = new System.Drawing.Size(108, 37);
            this.dccLabel2.TabIndex = 22;
            this.dccLabel2.Text = "DCC2";
            this.dccLabel2.Visible = false;
            // 
            // dcdLabel
            // 
            this.dcdLabel.AutoSize = true;
            this.dcdLabel.BackColor = System.Drawing.Color.White;
            this.dcdLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcdLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dcdLabel.Location = new System.Drawing.Point(390, 47);
            this.dcdLabel.Name = "dcdLabel";
            this.dcdLabel.Size = new System.Drawing.Size(58, 26);
            this.dcdLabel.TabIndex = 23;
            this.dcdLabel.Text = "DCD";
            this.dcdLabel.Visible = false;
            // 
            // dcdLabel2
            // 
            this.dcdLabel2.AutoSize = true;
            this.dcdLabel2.BackColor = System.Drawing.Color.White;
            this.dcdLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.dcdLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dcdLabel2.Location = new System.Drawing.Point(391, 83);
            this.dcdLabel2.Name = "dcdLabel2";
            this.dcdLabel2.Size = new System.Drawing.Size(108, 37);
            this.dcdLabel2.TabIndex = 24;
            this.dcdLabel2.Text = "DCD2";
            this.dcdLabel2.Visible = false;
            // 
            // dceLabel
            // 
            this.dceLabel.AutoSize = true;
            this.dceLabel.BackColor = System.Drawing.Color.White;
            this.dceLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dceLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dceLabel.Location = new System.Drawing.Point(468, 47);
            this.dceLabel.Name = "dceLabel";
            this.dceLabel.Size = new System.Drawing.Size(54, 26);
            this.dceLabel.TabIndex = 25;
            this.dceLabel.Text = "DCE";
            this.dceLabel.Visible = false;
            // 
            // dceLabel2
            // 
            this.dceLabel2.AutoSize = true;
            this.dceLabel2.BackColor = System.Drawing.Color.White;
            this.dceLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.dceLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dceLabel2.Location = new System.Drawing.Point(466, 83);
            this.dceLabel2.Name = "dceLabel2";
            this.dceLabel2.Size = new System.Drawing.Size(106, 37);
            this.dceLabel2.TabIndex = 26;
            this.dceLabel2.Text = "DCE2";
            this.dceLabel2.Visible = false;
            // 
            // dcfLabel
            // 
            this.dcfLabel.AutoSize = true;
            this.dcfLabel.BackColor = System.Drawing.Color.White;
            this.dcfLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcfLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dcfLabel.Location = new System.Drawing.Point(550, 47);
            this.dcfLabel.Name = "dcfLabel";
            this.dcfLabel.Size = new System.Drawing.Size(53, 26);
            this.dcfLabel.TabIndex = 27;
            this.dcfLabel.Text = "DCF";
            this.dcfLabel.Visible = false;
            // 
            // dcfLabel2
            // 
            this.dcfLabel2.AutoSize = true;
            this.dcfLabel2.BackColor = System.Drawing.Color.White;
            this.dcfLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.dcfLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dcfLabel2.Location = new System.Drawing.Point(560, 83);
            this.dcfLabel2.Name = "dcfLabel2";
            this.dcfLabel2.Size = new System.Drawing.Size(105, 37);
            this.dcfLabel2.TabIndex = 28;
            this.dcfLabel2.Text = "DCF2";
            this.dcfLabel2.Visible = false;
            // 
            // pccLabel
            // 
            this.pccLabel.AutoSize = true;
            this.pccLabel.BackColor = System.Drawing.Color.White;
            this.pccLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pccLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pccLabel.Location = new System.Drawing.Point(184, 251);
            this.pccLabel.Name = "pccLabel";
            this.pccLabel.Size = new System.Drawing.Size(52, 26);
            this.pccLabel.TabIndex = 29;
            this.pccLabel.Text = "PCC";
            this.pccLabel.Visible = false;
            // 
            // pccLabel2
            // 
            this.pccLabel2.AutoSize = true;
            this.pccLabel2.BackColor = System.Drawing.Color.White;
            this.pccLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pccLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pccLabel2.Location = new System.Drawing.Point(186, 287);
            this.pccLabel2.Name = "pccLabel2";
            this.pccLabel2.Size = new System.Drawing.Size(106, 37);
            this.pccLabel2.TabIndex = 30;
            this.pccLabel2.Text = "PCC2";
            this.pccLabel2.Visible = false;
            // 
            // pcdLabel
            // 
            this.pcdLabel.AutoSize = true;
            this.pcdLabel.BackColor = System.Drawing.Color.White;
            this.pcdLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcdLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pcdLabel.Location = new System.Drawing.Point(261, 251);
            this.pcdLabel.Name = "pcdLabel";
            this.pcdLabel.Size = new System.Drawing.Size(54, 26);
            this.pcdLabel.TabIndex = 31;
            this.pcdLabel.Text = "PCD";
            this.pcdLabel.Visible = false;
            // 
            // pcdLabel2
            // 
            this.pcdLabel2.AutoSize = true;
            this.pcdLabel2.BackColor = System.Drawing.Color.White;
            this.pcdLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pcdLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pcdLabel2.Location = new System.Drawing.Point(268, 287);
            this.pcdLabel2.Name = "pcdLabel2";
            this.pcdLabel2.Size = new System.Drawing.Size(106, 37);
            this.pcdLabel2.TabIndex = 32;
            this.pcdLabel2.Text = "PCD2";
            this.pcdLabel2.Visible = false;
            // 
            // pceLabel
            // 
            this.pceLabel.AutoSize = true;
            this.pceLabel.BackColor = System.Drawing.Color.White;
            this.pceLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pceLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pceLabel.Location = new System.Drawing.Point(349, 251);
            this.pceLabel.Name = "pceLabel";
            this.pceLabel.Size = new System.Drawing.Size(50, 26);
            this.pceLabel.TabIndex = 33;
            this.pceLabel.Text = "PCE";
            this.pceLabel.Visible = false;
            // 
            // pceLabel2
            // 
            this.pceLabel2.AutoSize = true;
            this.pceLabel2.BackColor = System.Drawing.Color.White;
            this.pceLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pceLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pceLabel2.Location = new System.Drawing.Point(361, 287);
            this.pceLabel2.Name = "pceLabel2";
            this.pceLabel2.Size = new System.Drawing.Size(104, 37);
            this.pceLabel2.TabIndex = 34;
            this.pceLabel2.Text = "PCE2";
            this.pceLabel2.Visible = false;
            // 
            // pcfLabel
            // 
            this.pcfLabel.AutoSize = true;
            this.pcfLabel.BackColor = System.Drawing.Color.White;
            this.pcfLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcfLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pcfLabel.Location = new System.Drawing.Point(431, 251);
            this.pcfLabel.Name = "pcfLabel";
            this.pcfLabel.Size = new System.Drawing.Size(49, 26);
            this.pcfLabel.TabIndex = 35;
            this.pcfLabel.Text = "PCF";
            this.pcfLabel.Visible = false;
            // 
            // pcfLabel2
            // 
            this.pcfLabel2.AutoSize = true;
            this.pcfLabel2.BackColor = System.Drawing.Color.White;
            this.pcfLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pcfLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pcfLabel2.Location = new System.Drawing.Point(437, 287);
            this.pcfLabel2.Name = "pcfLabel2";
            this.pcfLabel2.Size = new System.Drawing.Size(103, 37);
            this.pcfLabel2.TabIndex = 36;
            this.pcfLabel2.Text = "PCF2";
            this.pcfLabel2.Visible = false;
            // 
            // dcaPictureBox
            // 
            this.dcaPictureBox.BackColor = System.Drawing.Color.White;
            this.dcaPictureBox.Location = new System.Drawing.Point(127, 37);
            this.dcaPictureBox.Name = "dcaPictureBox";
            this.dcaPictureBox.Size = new System.Drawing.Size(76, 117);
            this.dcaPictureBox.TabIndex = 37;
            this.dcaPictureBox.TabStop = false;
            this.dcaPictureBox.Visible = false;
            // 
            // dcaLabel
            // 
            this.dcaLabel.AutoSize = true;
            this.dcaLabel.BackColor = System.Drawing.Color.White;
            this.dcaLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcaLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dcaLabel.Location = new System.Drawing.Point(136, 47);
            this.dcaLabel.Name = "dcaLabel";
            this.dcaLabel.Size = new System.Drawing.Size(57, 26);
            this.dcaLabel.TabIndex = 38;
            this.dcaLabel.Text = "DCA";
            this.dcaLabel.Visible = false;
            // 
            // dcaLabel2
            // 
            this.dcaLabel2.AutoSize = true;
            this.dcaLabel2.BackColor = System.Drawing.Color.White;
            this.dcaLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcaLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dcaLabel2.Location = new System.Drawing.Point(147, 83);
            this.dcaLabel2.Name = "dcaLabel2";
            this.dcaLabel2.Size = new System.Drawing.Size(107, 37);
            this.dcaLabel2.TabIndex = 39;
            this.dcaLabel2.Text = "DCA2";
            this.dcaLabel2.Visible = false;
            // 
            // dealButton
            // 
            this.dealButton.BackColor = System.Drawing.Color.White;
            this.dealButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealButton.ForeColor = System.Drawing.Color.Black;
            this.dealButton.Location = new System.Drawing.Point(12, 170);
            this.dealButton.Name = "dealButton";
            this.dealButton.Size = new System.Drawing.Size(107, 30);
            this.dealButton.TabIndex = 40;
            this.dealButton.Text = "Deal";
            this.dealButton.UseVisualStyleBackColor = false;
            this.dealButton.Click += new System.EventHandler(this.DealButton_Click);
            // 
            // hitButton
            // 
            this.hitButton.BackColor = System.Drawing.Color.White;
            this.hitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hitButton.ForeColor = System.Drawing.Color.Black;
            this.hitButton.Location = new System.Drawing.Point(657, 372);
            this.hitButton.Name = "hitButton";
            this.hitButton.Size = new System.Drawing.Size(107, 31);
            this.hitButton.TabIndex = 41;
            this.hitButton.Text = "Hit";
            this.hitButton.UseVisualStyleBackColor = false;
            this.hitButton.Visible = false;
            this.hitButton.Click += new System.EventHandler(this.HitButton_Click);
            // 
            // stayButton
            // 
            this.stayButton.BackColor = System.Drawing.Color.White;
            this.stayButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stayButton.ForeColor = System.Drawing.Color.Black;
            this.stayButton.Location = new System.Drawing.Point(657, 407);
            this.stayButton.Name = "stayButton";
            this.stayButton.Size = new System.Drawing.Size(106, 31);
            this.stayButton.TabIndex = 42;
            this.stayButton.Text = "Stay";
            this.stayButton.UseVisualStyleBackColor = false;
            this.stayButton.Visible = false;
            this.stayButton.Click += new System.EventHandler(this.StayButton_Click);
            // 
            // displayTextLabel
            // 
            this.displayTextLabel.AutoSize = true;
            this.displayTextLabel.BackColor = System.Drawing.Color.White;
            this.displayTextLabel.Font = new System.Drawing.Font("Palatino Linotype", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTextLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.displayTextLabel.Location = new System.Drawing.Point(708, 170);
            this.displayTextLabel.Name = "displayTextLabel";
            this.displayTextLabel.Size = new System.Drawing.Size(170, 49);
            this.displayTextLabel.TabIndex = 43;
            this.displayTextLabel.Text = "You Win.";
            this.displayTextLabel.Visible = false;
            // 
            // continueButton
            // 
            this.continueButton.BackColor = System.Drawing.Color.White;
            this.continueButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.continueButton.ForeColor = System.Drawing.Color.Black;
            this.continueButton.Location = new System.Drawing.Point(771, 407);
            this.continueButton.Name = "continueButton";
            this.continueButton.Size = new System.Drawing.Size(107, 31);
            this.continueButton.TabIndex = 44;
            this.continueButton.Text = "Continue";
            this.continueButton.UseVisualStyleBackColor = false;
            this.continueButton.Visible = false;
            this.continueButton.Click += new System.EventHandler(this.ContinueButton_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1057, 25);
            this.menuStrip1.TabIndex = 45;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.newGameToolStripMenuItem.Enabled = false;
            this.newGameToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.NewGameToolStripMenuItem_Click);
            // 
            // pWinsLabel
            // 
            this.pWinsLabel.AutoSize = true;
            this.pWinsLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pWinsLabel.Location = new System.Drawing.Point(785, 251);
            this.pWinsLabel.Name = "pWinsLabel";
            this.pWinsLabel.Size = new System.Drawing.Size(22, 26);
            this.pWinsLabel.TabIndex = 46;
            this.pWinsLabel.Text = "0";
            // 
            // dWinsLabel
            // 
            this.dWinsLabel.AutoSize = true;
            this.dWinsLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dWinsLabel.Location = new System.Drawing.Point(785, 287);
            this.dWinsLabel.Name = "dWinsLabel";
            this.dWinsLabel.Size = new System.Drawing.Size(22, 26);
            this.dWinsLabel.TabIndex = 47;
            this.dWinsLabel.Text = "0";
            // 
            // winPercentLabel
            // 
            this.winPercentLabel.AutoSize = true;
            this.winPercentLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winPercentLabel.Location = new System.Drawing.Point(785, 324);
            this.winPercentLabel.Name = "winPercentLabel";
            this.winPercentLabel.Size = new System.Drawing.Size(22, 26);
            this.winPercentLabel.TabIndex = 48;
            this.winPercentLabel.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(652, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 26);
            this.label1.TabIndex = 49;
            this.label1.Text = "Player Wins:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(652, 287);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 26);
            this.label2.TabIndex = 50;
            this.label2.Text = "Dealer Wins:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(652, 324);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 26);
            this.label3.TabIndex = 51;
            this.label3.Text = "Win Percent:";
            // 
            // dcgPictureBox
            // 
            this.dcgPictureBox.BackColor = System.Drawing.Color.White;
            this.dcgPictureBox.Location = new System.Drawing.Point(189, 123);
            this.dcgPictureBox.Name = "dcgPictureBox";
            this.dcgPictureBox.Size = new System.Drawing.Size(76, 114);
            this.dcgPictureBox.TabIndex = 52;
            this.dcgPictureBox.TabStop = false;
            this.dcgPictureBox.Visible = false;
            // 
            // dchPictureBox
            // 
            this.dchPictureBox.BackColor = System.Drawing.Color.White;
            this.dchPictureBox.Location = new System.Drawing.Point(272, 123);
            this.dchPictureBox.Name = "dchPictureBox";
            this.dchPictureBox.Size = new System.Drawing.Size(76, 114);
            this.dchPictureBox.TabIndex = 53;
            this.dchPictureBox.TabStop = false;
            this.dchPictureBox.Visible = false;
            // 
            // dciPictureBox
            // 
            this.dciPictureBox.BackColor = System.Drawing.Color.White;
            this.dciPictureBox.Location = new System.Drawing.Point(354, 123);
            this.dciPictureBox.Name = "dciPictureBox";
            this.dciPictureBox.Size = new System.Drawing.Size(76, 114);
            this.dciPictureBox.TabIndex = 54;
            this.dciPictureBox.TabStop = false;
            this.dciPictureBox.Visible = false;
            // 
            // dcjPictureBox
            // 
            this.dcjPictureBox.BackColor = System.Drawing.Color.White;
            this.dcjPictureBox.Location = new System.Drawing.Point(436, 123);
            this.dcjPictureBox.Name = "dcjPictureBox";
            this.dcjPictureBox.Size = new System.Drawing.Size(76, 114);
            this.dcjPictureBox.TabIndex = 55;
            this.dcjPictureBox.TabStop = false;
            this.dcjPictureBox.Visible = false;
            // 
            // dckPictureBox
            // 
            this.dckPictureBox.BackColor = System.Drawing.Color.White;
            this.dckPictureBox.Location = new System.Drawing.Point(518, 123);
            this.dckPictureBox.Name = "dckPictureBox";
            this.dckPictureBox.Size = new System.Drawing.Size(76, 114);
            this.dckPictureBox.TabIndex = 56;
            this.dckPictureBox.TabStop = false;
            this.dckPictureBox.Visible = false;
            // 
            // pcgPictureBox
            // 
            this.pcgPictureBox.BackColor = System.Drawing.Color.White;
            this.pcgPictureBox.Location = new System.Drawing.Point(54, 324);
            this.pcgPictureBox.Name = "pcgPictureBox";
            this.pcgPictureBox.Size = new System.Drawing.Size(76, 114);
            this.pcgPictureBox.TabIndex = 57;
            this.pcgPictureBox.TabStop = false;
            this.pcgPictureBox.Visible = false;
            // 
            // pchPictureBox
            // 
            this.pchPictureBox.BackColor = System.Drawing.Color.White;
            this.pchPictureBox.Location = new System.Drawing.Point(136, 324);
            this.pchPictureBox.Name = "pchPictureBox";
            this.pchPictureBox.Size = new System.Drawing.Size(76, 114);
            this.pchPictureBox.TabIndex = 58;
            this.pchPictureBox.TabStop = false;
            this.pchPictureBox.Visible = false;
            // 
            // pciPictureBox
            // 
            this.pciPictureBox.BackColor = System.Drawing.Color.White;
            this.pciPictureBox.Location = new System.Drawing.Point(218, 324);
            this.pciPictureBox.Name = "pciPictureBox";
            this.pciPictureBox.Size = new System.Drawing.Size(76, 114);
            this.pciPictureBox.TabIndex = 59;
            this.pciPictureBox.TabStop = false;
            this.pciPictureBox.Visible = false;
            // 
            // pcjPictureBox
            // 
            this.pcjPictureBox.BackColor = System.Drawing.Color.White;
            this.pcjPictureBox.Location = new System.Drawing.Point(300, 324);
            this.pcjPictureBox.Name = "pcjPictureBox";
            this.pcjPictureBox.Size = new System.Drawing.Size(76, 114);
            this.pcjPictureBox.TabIndex = 60;
            this.pcjPictureBox.TabStop = false;
            this.pcjPictureBox.Visible = false;
            // 
            // pckPictureBox
            // 
            this.pckPictureBox.BackColor = System.Drawing.Color.White;
            this.pckPictureBox.Location = new System.Drawing.Point(382, 324);
            this.pckPictureBox.Name = "pckPictureBox";
            this.pckPictureBox.Size = new System.Drawing.Size(76, 114);
            this.pckPictureBox.TabIndex = 61;
            this.pckPictureBox.TabStop = false;
            this.pckPictureBox.Visible = false;
            // 
            // dcgLabel
            // 
            this.dcgLabel.AutoSize = true;
            this.dcgLabel.BackColor = System.Drawing.Color.White;
            this.dcgLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcgLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dcgLabel.Location = new System.Drawing.Point(204, 128);
            this.dcgLabel.Name = "dcgLabel";
            this.dcgLabel.Size = new System.Drawing.Size(58, 26);
            this.dcgLabel.TabIndex = 62;
            this.dcgLabel.Text = "DCG";
            this.dcgLabel.Visible = false;
            // 
            // dchLabel
            // 
            this.dchLabel.AutoSize = true;
            this.dchLabel.BackColor = System.Drawing.Color.White;
            this.dchLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dchLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dchLabel.Location = new System.Drawing.Point(286, 128);
            this.dchLabel.Name = "dchLabel";
            this.dchLabel.Size = new System.Drawing.Size(58, 26);
            this.dchLabel.TabIndex = 63;
            this.dchLabel.Text = "DCH";
            this.dchLabel.Visible = false;
            // 
            // dciLabel
            // 
            this.dciLabel.AutoSize = true;
            this.dciLabel.BackColor = System.Drawing.Color.White;
            this.dciLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dciLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dciLabel.Location = new System.Drawing.Point(363, 128);
            this.dciLabel.Name = "dciLabel";
            this.dciLabel.Size = new System.Drawing.Size(49, 26);
            this.dciLabel.TabIndex = 64;
            this.dciLabel.Text = "DCI";
            this.dciLabel.Visible = false;
            // 
            // dcjLabel
            // 
            this.dcjLabel.AutoSize = true;
            this.dcjLabel.BackColor = System.Drawing.Color.White;
            this.dcjLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcjLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dcjLabel.Location = new System.Drawing.Point(449, 128);
            this.dcjLabel.Name = "dcjLabel";
            this.dcjLabel.Size = new System.Drawing.Size(49, 26);
            this.dcjLabel.TabIndex = 65;
            this.dcjLabel.Text = "DCJ";
            this.dcjLabel.Visible = false;
            // 
            // dckLabel
            // 
            this.dckLabel.AutoSize = true;
            this.dckLabel.BackColor = System.Drawing.Color.White;
            this.dckLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dckLabel.ForeColor = System.Drawing.Color.Maroon;
            this.dckLabel.Location = new System.Drawing.Point(531, 128);
            this.dckLabel.Name = "dckLabel";
            this.dckLabel.Size = new System.Drawing.Size(57, 26);
            this.dckLabel.TabIndex = 66;
            this.dckLabel.Text = "DCK";
            this.dckLabel.Visible = false;
            // 
            // pcgLabel
            // 
            this.pcgLabel.AutoSize = true;
            this.pcgLabel.BackColor = System.Drawing.Color.White;
            this.pcgLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcgLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pcgLabel.Location = new System.Drawing.Point(66, 330);
            this.pcgLabel.Name = "pcgLabel";
            this.pcgLabel.Size = new System.Drawing.Size(54, 26);
            this.pcgLabel.TabIndex = 67;
            this.pcgLabel.Text = "PCG";
            this.pcgLabel.Visible = false;
            // 
            // pchLabel
            // 
            this.pchLabel.AutoSize = true;
            this.pchLabel.BackColor = System.Drawing.Color.White;
            this.pchLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pchLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pchLabel.Location = new System.Drawing.Point(149, 332);
            this.pchLabel.Name = "pchLabel";
            this.pchLabel.Size = new System.Drawing.Size(54, 26);
            this.pchLabel.TabIndex = 68;
            this.pchLabel.Text = "PCH";
            this.pchLabel.Visible = false;
            // 
            // pciLabel
            // 
            this.pciLabel.AutoSize = true;
            this.pciLabel.BackColor = System.Drawing.Color.White;
            this.pciLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pciLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pciLabel.Location = new System.Drawing.Point(228, 330);
            this.pciLabel.Name = "pciLabel";
            this.pciLabel.Size = new System.Drawing.Size(45, 26);
            this.pciLabel.TabIndex = 69;
            this.pciLabel.Text = "PCI";
            this.pciLabel.Visible = false;
            // 
            // pcjLabel
            // 
            this.pcjLabel.AutoSize = true;
            this.pcjLabel.BackColor = System.Drawing.Color.White;
            this.pcjLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcjLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pcjLabel.Location = new System.Drawing.Point(312, 330);
            this.pcjLabel.Name = "pcjLabel";
            this.pcjLabel.Size = new System.Drawing.Size(45, 26);
            this.pcjLabel.TabIndex = 70;
            this.pcjLabel.Text = "PCJ";
            this.pcjLabel.Visible = false;
            // 
            // pckLabel
            // 
            this.pckLabel.AutoSize = true;
            this.pckLabel.BackColor = System.Drawing.Color.White;
            this.pckLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pckLabel.ForeColor = System.Drawing.Color.Maroon;
            this.pckLabel.Location = new System.Drawing.Point(390, 332);
            this.pckLabel.Name = "pckLabel";
            this.pckLabel.Size = new System.Drawing.Size(53, 26);
            this.pckLabel.TabIndex = 71;
            this.pckLabel.Text = "PCK";
            this.pckLabel.Visible = false;
            // 
            // dcgLabel2
            // 
            this.dcgLabel2.AutoSize = true;
            this.dcgLabel2.BackColor = System.Drawing.Color.White;
            this.dcgLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcgLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dcgLabel2.Location = new System.Drawing.Point(205, 163);
            this.dcgLabel2.Name = "dcgLabel2";
            this.dcgLabel2.Size = new System.Drawing.Size(110, 37);
            this.dcgLabel2.TabIndex = 72;
            this.dcgLabel2.Text = "DCG2";
            this.dcgLabel2.Visible = false;
            // 
            // dchLabel2
            // 
            this.dchLabel2.AutoSize = true;
            this.dchLabel2.BackColor = System.Drawing.Color.White;
            this.dchLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dchLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dchLabel2.Location = new System.Drawing.Point(284, 163);
            this.dchLabel2.Name = "dchLabel2";
            this.dchLabel2.Size = new System.Drawing.Size(108, 37);
            this.dchLabel2.TabIndex = 73;
            this.dchLabel2.Text = "DCH2";
            this.dchLabel2.Visible = false;
            // 
            // dciLabel2
            // 
            this.dciLabel2.AutoSize = true;
            this.dciLabel2.BackColor = System.Drawing.Color.White;
            this.dciLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dciLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dciLabel2.Location = new System.Drawing.Point(365, 163);
            this.dciLabel2.Name = "dciLabel2";
            this.dciLabel2.Size = new System.Drawing.Size(93, 37);
            this.dciLabel2.TabIndex = 74;
            this.dciLabel2.Text = "DCI2";
            this.dciLabel2.Visible = false;
            // 
            // dcjLabel2
            // 
            this.dcjLabel2.AutoSize = true;
            this.dcjLabel2.BackColor = System.Drawing.Color.White;
            this.dcjLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcjLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dcjLabel2.Location = new System.Drawing.Point(447, 163);
            this.dcjLabel2.Name = "dcjLabel2";
            this.dcjLabel2.Size = new System.Drawing.Size(101, 37);
            this.dcjLabel2.TabIndex = 75;
            this.dcjLabel2.Text = "DCJ2";
            this.dcjLabel2.Visible = false;
            // 
            // dckLabel2
            // 
            this.dckLabel2.AutoSize = true;
            this.dckLabel2.BackColor = System.Drawing.Color.White;
            this.dckLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dckLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.dckLabel2.Location = new System.Drawing.Point(529, 163);
            this.dckLabel2.Name = "dckLabel2";
            this.dckLabel2.Size = new System.Drawing.Size(106, 37);
            this.dckLabel2.TabIndex = 76;
            this.dckLabel2.Text = "DCK2";
            this.dckLabel2.Visible = false;
            // 
            // pcgLabel2
            // 
            this.pcgLabel2.AutoSize = true;
            this.pcgLabel2.BackColor = System.Drawing.Color.White;
            this.pcgLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pcgLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pcgLabel2.Location = new System.Drawing.Point(75, 364);
            this.pcgLabel2.Name = "pcgLabel2";
            this.pcgLabel2.Size = new System.Drawing.Size(108, 37);
            this.pcgLabel2.TabIndex = 77;
            this.pcgLabel2.Text = "PCG2";
            this.pcgLabel2.Visible = false;
            // 
            // pchLabel2
            // 
            this.pchLabel2.AutoSize = true;
            this.pchLabel2.BackColor = System.Drawing.Color.White;
            this.pchLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pchLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pchLabel2.Location = new System.Drawing.Point(156, 364);
            this.pchLabel2.Name = "pchLabel2";
            this.pchLabel2.Size = new System.Drawing.Size(106, 37);
            this.pchLabel2.TabIndex = 78;
            this.pchLabel2.Text = "PCH2";
            this.pchLabel2.Visible = false;
            // 
            // pciLabel2
            // 
            this.pciLabel2.AutoSize = true;
            this.pciLabel2.BackColor = System.Drawing.Color.White;
            this.pciLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pciLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pciLabel2.Location = new System.Drawing.Point(228, 364);
            this.pciLabel2.Name = "pciLabel2";
            this.pciLabel2.Size = new System.Drawing.Size(91, 37);
            this.pciLabel2.TabIndex = 79;
            this.pciLabel2.Text = "PCI2";
            this.pciLabel2.Visible = false;
            // 
            // pcjLabel2
            // 
            this.pcjLabel2.AutoSize = true;
            this.pcjLabel2.BackColor = System.Drawing.Color.White;
            this.pcjLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pcjLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pcjLabel2.Location = new System.Drawing.Point(314, 364);
            this.pcjLabel2.Name = "pcjLabel2";
            this.pcjLabel2.Size = new System.Drawing.Size(99, 37);
            this.pcjLabel2.TabIndex = 80;
            this.pcjLabel2.Text = "PCJ2";
            this.pcjLabel2.Visible = false;
            // 
            // pckLabel2
            // 
            this.pckLabel2.AutoSize = true;
            this.pckLabel2.BackColor = System.Drawing.Color.White;
            this.pckLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.pckLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.pckLabel2.Location = new System.Drawing.Point(395, 364);
            this.pckLabel2.Name = "pckLabel2";
            this.pckLabel2.Size = new System.Drawing.Size(104, 37);
            this.pckLabel2.TabIndex = 81;
            this.pckLabel2.Text = "PCK2";
            this.pckLabel2.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(1057, 456);
            this.Controls.Add(this.pckLabel2);
            this.Controls.Add(this.pcjLabel2);
            this.Controls.Add(this.pciLabel2);
            this.Controls.Add(this.pchLabel2);
            this.Controls.Add(this.pcgLabel2);
            this.Controls.Add(this.dckLabel2);
            this.Controls.Add(this.dcjLabel2);
            this.Controls.Add(this.dciLabel2);
            this.Controls.Add(this.dchLabel2);
            this.Controls.Add(this.dcgLabel2);
            this.Controls.Add(this.pckLabel);
            this.Controls.Add(this.pcjLabel);
            this.Controls.Add(this.pciLabel);
            this.Controls.Add(this.pchLabel);
            this.Controls.Add(this.pcgLabel);
            this.Controls.Add(this.dckLabel);
            this.Controls.Add(this.dcjLabel);
            this.Controls.Add(this.dciLabel);
            this.Controls.Add(this.dchLabel);
            this.Controls.Add(this.dcgLabel);
            this.Controls.Add(this.pckPictureBox);
            this.Controls.Add(this.pcjPictureBox);
            this.Controls.Add(this.pciPictureBox);
            this.Controls.Add(this.pchPictureBox);
            this.Controls.Add(this.pcgPictureBox);
            this.Controls.Add(this.dckPictureBox);
            this.Controls.Add(this.dcjPictureBox);
            this.Controls.Add(this.dciPictureBox);
            this.Controls.Add(this.dchPictureBox);
            this.Controls.Add(this.dcgPictureBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.winPercentLabel);
            this.Controls.Add(this.dWinsLabel);
            this.Controls.Add(this.pWinsLabel);
            this.Controls.Add(this.continueButton);
            this.Controls.Add(this.displayTextLabel);
            this.Controls.Add(this.stayButton);
            this.Controls.Add(this.hitButton);
            this.Controls.Add(this.dealButton);
            this.Controls.Add(this.dcaLabel2);
            this.Controls.Add(this.dcaLabel);
            this.Controls.Add(this.dcaPictureBox);
            this.Controls.Add(this.pcfLabel2);
            this.Controls.Add(this.pcfLabel);
            this.Controls.Add(this.pceLabel2);
            this.Controls.Add(this.pceLabel);
            this.Controls.Add(this.pcdLabel2);
            this.Controls.Add(this.pcdLabel);
            this.Controls.Add(this.pccLabel2);
            this.Controls.Add(this.pccLabel);
            this.Controls.Add(this.dcfLabel2);
            this.Controls.Add(this.dcfLabel);
            this.Controls.Add(this.dceLabel2);
            this.Controls.Add(this.dceLabel);
            this.Controls.Add(this.dcdLabel2);
            this.Controls.Add(this.dcdLabel);
            this.Controls.Add(this.dccLabel2);
            this.Controls.Add(this.dccLabel);
            this.Controls.Add(this.dcfPictureBox);
            this.Controls.Add(this.pcfPictureBox);
            this.Controls.Add(this.dcePictureBox);
            this.Controls.Add(this.dcdPictureBox);
            this.Controls.Add(this.dccPictureBox);
            this.Controls.Add(this.pcePictureBox);
            this.Controls.Add(this.pcdPictureBox);
            this.Controls.Add(this.pccPictureBox);
            this.Controls.Add(this.dcbLabel2);
            this.Controls.Add(this.dcbLabel);
            this.Controls.Add(this.dcbPictureBox);
            this.Controls.Add(this.dcoPictureBox);
            this.Controls.Add(this.pcbLabel2);
            this.Controls.Add(this.pcbLabel);
            this.Controls.Add(this.pcbPictureBox);
            this.Controls.Add(this.pcaLabel2);
            this.Controls.Add(this.pcaLabel);
            this.Controls.Add(this.pcaPictureBox);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "BlackJackTable";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcaPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcbPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pccPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcdPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dccPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcdPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcfPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcfPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcaPictureBox)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcgPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dchPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dciPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcjPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dckPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcgPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pchPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pciPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcjPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pckPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pcaPictureBox;
        private System.Windows.Forms.Label pcaLabel;
        private System.Windows.Forms.Label pcaLabel2;
        private System.Windows.Forms.PictureBox pcbPictureBox;
        private System.Windows.Forms.Label pcbLabel;
        private System.Windows.Forms.Label pcbLabel2;
        private System.Windows.Forms.PictureBox dcoPictureBox;
        private System.Windows.Forms.PictureBox dcbPictureBox;
        private System.Windows.Forms.Label dcbLabel;
        private System.Windows.Forms.Label dcbLabel2;
        private System.Windows.Forms.PictureBox pccPictureBox;
        private System.Windows.Forms.PictureBox pcdPictureBox;
        private System.Windows.Forms.PictureBox pcePictureBox;
        private System.Windows.Forms.PictureBox dccPictureBox;
        private System.Windows.Forms.PictureBox dcdPictureBox;
        private System.Windows.Forms.PictureBox dcePictureBox;
        private System.Windows.Forms.PictureBox pcfPictureBox;
        private System.Windows.Forms.PictureBox dcfPictureBox;
        private System.Windows.Forms.Label dccLabel;
        private System.Windows.Forms.Label dccLabel2;
        private System.Windows.Forms.Label dcdLabel;
        private System.Windows.Forms.Label dcdLabel2;
        private System.Windows.Forms.Label dceLabel;
        private System.Windows.Forms.Label dceLabel2;
        private System.Windows.Forms.Label dcfLabel;
        private System.Windows.Forms.Label dcfLabel2;
        private System.Windows.Forms.Label pccLabel;
        private System.Windows.Forms.Label pccLabel2;
        private System.Windows.Forms.Label pcdLabel;
        private System.Windows.Forms.Label pcdLabel2;
        private System.Windows.Forms.Label pceLabel;
        private System.Windows.Forms.Label pceLabel2;
        private System.Windows.Forms.Label pcfLabel;
        private System.Windows.Forms.Label pcfLabel2;
        private System.Windows.Forms.PictureBox dcaPictureBox;
        private System.Windows.Forms.Label dcaLabel;
        private System.Windows.Forms.Label dcaLabel2;
        private System.Windows.Forms.Button dealButton;
        private System.Windows.Forms.Button hitButton;
        private System.Windows.Forms.Button stayButton;
        private System.Windows.Forms.Label displayTextLabel;
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.Label pWinsLabel;
        private System.Windows.Forms.Label dWinsLabel;
        private System.Windows.Forms.Label winPercentLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox dcgPictureBox;
        private System.Windows.Forms.PictureBox dchPictureBox;
        private System.Windows.Forms.PictureBox dciPictureBox;
        private System.Windows.Forms.PictureBox dcjPictureBox;
        private System.Windows.Forms.PictureBox dckPictureBox;
        private System.Windows.Forms.PictureBox pcgPictureBox;
        private System.Windows.Forms.PictureBox pchPictureBox;
        private System.Windows.Forms.PictureBox pciPictureBox;
        private System.Windows.Forms.PictureBox pcjPictureBox;
        private System.Windows.Forms.PictureBox pckPictureBox;
        private System.Windows.Forms.Label dcgLabel;
        private System.Windows.Forms.Label dchLabel;
        private System.Windows.Forms.Label dciLabel;
        private System.Windows.Forms.Label dcjLabel;
        private System.Windows.Forms.Label dckLabel;
        private System.Windows.Forms.Label pcgLabel;
        private System.Windows.Forms.Label pchLabel;
        private System.Windows.Forms.Label pciLabel;
        private System.Windows.Forms.Label pcjLabel;
        private System.Windows.Forms.Label pckLabel;
        private System.Windows.Forms.Label dcgLabel2;
        private System.Windows.Forms.Label dchLabel2;
        private System.Windows.Forms.Label dciLabel2;
        private System.Windows.Forms.Label dcjLabel2;
        private System.Windows.Forms.Label dckLabel2;
        private System.Windows.Forms.Label pcgLabel2;
        private System.Windows.Forms.Label pchLabel2;
        private System.Windows.Forms.Label pciLabel2;
        private System.Windows.Forms.Label pcjLabel2;
        private System.Windows.Forms.Label pckLabel2;
    }
}

