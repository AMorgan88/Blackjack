﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJackGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        class Card
        {
            public string name;
            public int value;
            public string suit;
            
            public static List<Card> CheckPlayerAce(List<Card> PlayerHands)
            {
                foreach (Card PlayerHand in PlayerHands)
                {
                    if (PlayerHand.value == 11)
                    {
                        PlayerHand.value = 1;
                        break;
                    }
                }
                return PlayerHands;
            }

            public static List<Card> CheckDealerAce(List<Card> DealerHands)
            {
                foreach (Card DealerHand in DealerHands)
                {
                    if (DealerHand.value == 11)
                    {
                        DealerHand.value = 1;
                        break;
                    }
                }
                return DealerHands;
            }

            public static void FlipCard(Label label1, Label label2, Card card, PictureBox pictureBox)
            {
                label1.Text = card.name;
                label1.Visible = true;
                label2.Text = card.suit;
                label2.Visible = true;
                pictureBox.Visible = true;
            }

            public static void CheckSuit(Label label1, Label label2, Card card)
            {
                if (card.suit == "\u2660" || card.suit == "\u2663")
                {
                    label1.ForeColor = Color.Black;
                    label2.ForeColor = Color.Black;
                }
            }

            public static float CalcTotalGames(float one, float two, Label label)
            {
                label.Text = one.ToString();
                float games = two + one;
                
                return games;
            }

            public static void DisplayWinPercent(float one, float two, Label label)
            {
              
                if (one == 0)
                {
                    label.Text = one.ToString() + "%";
                }
                else
                {
                    float percent = (one * 100) / two;
                    label.Text = percent.ToString() + "%";
                }
            }

            public static int CheckPlayerSum(List<Card> cards)
            {
                int psum = 0;
                foreach (Card card in cards)
                {
                    psum += card.value;
                }
                return psum;
            }

            public static int CheckDealerSum(List<Card> cards)
            {
                int dsum = 0;
                foreach (Card card in cards)
                {
                    dsum += card.value;
                }
                return dsum;
            }

            public static void Win(Label label)
            {
                label.Text = "You Win.";
                label.ForeColor = Color.DarkGreen;
                label.Visible = true;
            }

            public static void Lose(Label label)
            {
                label.Text = "You Lose.";
                label.ForeColor = Color.Maroon;
                label.Visible = true;
            }

            private static Random r = new Random();
            public static int RMethod(int DeckOfCards)
            {
                return r.Next(DeckOfCards);
            }
        }
        
        List<Card> DeckOfCards = new List<Card>()
        {
            new Card() {name = "A", suit = "\u2660", value = 11},
            new Card() {name = "2", suit = "\u2660", value = 2},
            new Card() {name = "3", suit = "\u2660", value = 3},
            new Card() {name = "4", suit = "\u2660", value = 4},
            new Card() {name = "5", suit = "\u2660", value = 5},
            new Card() {name = "6", suit = "\u2660", value = 6},
            new Card() {name = "7", suit = "\u2660", value = 7},
            new Card() {name = "8", suit = "\u2660", value = 8},
            new Card() {name = "9", suit = "\u2660", value = 9},
            new Card() {name = "10", suit = "\u2660", value = 10},
            new Card() {name = "J", suit = "\u2660", value = 10},
            new Card() {name = "Q", suit = "\u2660", value = 10},
            new Card() {name = "K", suit = "\u2660", value = 10},
            new Card() {name = "A", suit = "\u2663", value = 11},
            new Card() {name = "2", suit = "\u2663", value = 2},
            new Card() {name = "3", suit = "\u2663", value = 3},
            new Card() {name = "4", suit = "\u2663", value = 4},
            new Card() {name = "5", suit = "\u2663", value = 5},
            new Card() {name = "6", suit = "\u2663", value = 6},
            new Card() {name = "7", suit = "\u2663", value = 7},
            new Card() {name = "8", suit = "\u2663", value = 8},
            new Card() {name = "9", suit = "\u2663", value = 9},
            new Card() {name = "10", suit = "\u2663", value = 10},
            new Card() {name = "J", suit = "\u2663", value = 10},
            new Card() {name = "Q", suit = "\u2663", value = 10},
            new Card() {name = "K", suit = "\u2663", value = 10},
            new Card() {name = "A", suit = "\u2666", value = 11},
            new Card() {name = "2", suit = "\u2666", value = 2},
            new Card() {name = "3", suit = "\u2666", value = 3},
            new Card() {name = "4", suit = "\u2666", value = 4},
            new Card() {name = "5", suit = "\u2666", value = 5},
            new Card() {name = "6", suit = "\u2666", value = 6},
            new Card() {name = "7", suit = "\u2666", value = 7},
            new Card() {name = "8", suit = "\u2666", value = 8},
            new Card() {name = "9", suit = "\u2666", value = 9},
            new Card() {name = "10", suit = "\u2666", value = 10},
            new Card() {name = "J", suit = "\u2666", value = 10},
            new Card() {name = "Q", suit = "\u2666", value = 10},
            new Card() {name = "K", suit = "\u2666", value = 10},
            new Card() {name = "A", suit = "\u2665", value = 11},
            new Card() {name = "2", suit = "\u2665", value = 2},
            new Card() {name = "3", suit = "\u2665", value = 3},
            new Card() {name = "4", suit = "\u2665", value = 4},
            new Card() {name = "5", suit = "\u2665", value = 5},
            new Card() {name = "6", suit = "\u2665", value = 6},
            new Card() {name = "7", suit = "\u2665", value = 7},
            new Card() {name = "8", suit = "\u2665", value = 8},
            new Card() {name = "9", suit = "\u2665", value = 9},
            new Card() {name = "10", suit = "\u2665", value = 10},
            new Card() {name = "J", suit = "\u2665", value = 10},
            new Card() {name = "Q", suit = "\u2665", value = 10},
            new Card() {name = "K", suit = "\u2665", value = 10},
        };

        List<Card> PlayerHands = new List<Card>();
        List<Card> DealerHands = new List<Card>();

        public float pWin = 0.00f;
        public float dWin = 0.00f;
        public float games;
        public float percent;

        private void DealButton_Click(object sender, EventArgs e)
        {
            Card pcard1 = DeckOfCards[Card.RMethod(DeckOfCards.Count)];
            Card.CheckSuit(pcaLabel, pcaLabel2, pcard1);
            PlayerHands.Add(pcard1);
            Card.FlipCard(pcaLabel, pcaLabel2, pcard1, pcaPictureBox);
            DeckOfCards.Remove(pcard1);

            Card dcard1 = DeckOfCards[Card.RMethod(DeckOfCards.Count)];
            Card.CheckSuit(dcaLabel, dcaLabel2, dcard1);
            DealerHands.Add(dcard1);
            dcaLabel.Text = dcard1.name;
            dcaLabel2.Text = dcard1.suit;
            DeckOfCards.Remove(dcard1);

            Card pcard2 = DeckOfCards[Card.RMethod(DeckOfCards.Count)];
            Card.CheckSuit(pcbLabel, pcbLabel2, pcard2);
            PlayerHands.Add(pcard2);
            Card.FlipCard(pcbLabel, pcbLabel2, pcard2, pcbPictureBox);
            DeckOfCards.Remove(pcard2);

            Card dcard2 = DeckOfCards[Card.RMethod(DeckOfCards.Count)];
            Card.CheckSuit(dcbLabel, dcbLabel2, dcard2);
            DealerHands.Add(dcard2);
            dcbLabel.Text = dcard2.name;
            dcbLabel2.Text = dcard2.suit;
            DeckOfCards.Remove(dcard2);
            
            int psum = Card.CheckPlayerSum(PlayerHands);
            int dsum = Card.CheckDealerSum(DealerHands);

            if (psum == 21)
            {
                if (psum == dsum)
                {
                    Card.Lose(displayTextLabel);
                    Card.FlipCard(dcaLabel, dcaLabel2, dcard1, dcaPictureBox);
                    Card.FlipCard(dcbLabel, dcbLabel2, dcard2, dcbPictureBox);
                    dealButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    dWin++;
                    games = Card.CalcTotalGames(dWin, pWin, dWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }

                else if (psum != dsum)
                {
                    Card.Win(displayTextLabel);
                    Card.FlipCard(dcaLabel, dcaLabel2, dcard1, dcaPictureBox);
                    Card.FlipCard(dcbLabel, dcbLabel2, dcard2, dcbPictureBox);
                    dealButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    pWin++;
                    games = Card.CalcTotalGames(pWin, dWin, pWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }
            }
            else
            {
                dcoPictureBox.Visible = true;
                Card.FlipCard(dcbLabel, dcbLabel2, dcard2, dcbPictureBox);
                dealButton.Visible = false;
                hitButton.Visible = true;
                stayButton.Visible = true;
            }
        }

        private void HitButton_Click(object sender, EventArgs e)
        {
            Card pcard = DeckOfCards[Card.RMethod(DeckOfCards.Count)];

            int playerHit = PlayerHands.Count;

            if (playerHit == 2)
            {
                Card.CheckSuit(pccLabel, pccLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pccLabel, pccLabel2, pcard, pccPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 3)
            {
                Card.CheckSuit(pcdLabel, pcdLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pcdLabel, pcdLabel2, pcard, pcdPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 4)
            {
                Card.CheckSuit(pceLabel, pceLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pceLabel, pceLabel2, pcard, pcePictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 5)
            {
                Card.CheckSuit(pcfLabel, pcfLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pcfLabel, pcfLabel2, pcard, pcfPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 6)
            {
                Card.CheckSuit(pcgLabel, pcgLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pcgLabel, pcgLabel2, pcard, pcgPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 7)
            {
                Card.CheckSuit(pchLabel, pchLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pchLabel, pchLabel2, pcard, pchPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 8)
            {
                Card.CheckSuit(pciLabel, pciLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pciLabel, pciLabel2, pcard, pciPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 9)
            {
                Card.CheckSuit(pcjLabel, pcjLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pcjLabel, pcjLabel2, pcard, pcjPictureBox);
                DeckOfCards.Remove(pcard);
            }
            else if (playerHit == 10)
            {
                Card.CheckSuit(pckLabel, pckLabel2, pcard);
                PlayerHands.Add(pcard);
                Card.FlipCard(pckLabel, pckLabel2, pcard, pckPictureBox);
                DeckOfCards.Remove(pcard);
            }

            int psum = Card.CheckPlayerSum(PlayerHands);

            if (psum > 21)
            {
                PlayerHands = Card.CheckPlayerAce(PlayerHands);
                psum = Card.CheckPlayerSum(PlayerHands);

                if (psum > 21)
                {
                    Card.Lose(displayTextLabel);
                    hitButton.Visible = false;
                    stayButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    dWin++;
                    games = Card.CalcTotalGames(dWin, pWin, dWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }
            }
        }

        private void StayButton_Click(object sender, EventArgs e)
        {
            hitButton.Visible = false;
            stayButton.Visible = false;
            dcaLabel.Visible = true;
            dcaLabel2.Visible = true;
            dcaPictureBox.Visible = true;
            dcoPictureBox.Visible = false;

            int psum = Card.CheckPlayerSum(PlayerHands);
            int dsum = Card.CheckDealerSum(DealerHands);

            if (dsum < 16)
            {
                continueButton.Visible = true;
            }
            else if (dsum > 21)
            {
                Card.Win(displayTextLabel);
                newGameToolStripMenuItem.Enabled = true;

                dWin++;
                games = Card.CalcTotalGames(dWin, pWin, dWinsLabel);
                Card.DisplayWinPercent(pWin, games, winPercentLabel);
            }
            else if (dsum < psum)
            {
                Card.Win(displayTextLabel);
                newGameToolStripMenuItem.Enabled = true;

                pWin++;
                games = Card.CalcTotalGames(pWin, dWin, pWinsLabel);
                Card.DisplayWinPercent(pWin, games, winPercentLabel);
            }
            else if (dsum > psum)
            {
                Card.Lose(displayTextLabel);
                newGameToolStripMenuItem.Enabled = true;

                dWin++;
                games = Card.CalcTotalGames(dWin, pWin, dWinsLabel);
                Card.DisplayWinPercent(pWin, games, winPercentLabel);
            }
            else if (dsum == psum)
            {
                Card.Lose(displayTextLabel);
                newGameToolStripMenuItem.Enabled = true;

                pWin++;
                games = Card.CalcTotalGames(pWin, dWin, pWinsLabel);
                Card.DisplayWinPercent(pWin, games, winPercentLabel);
            }
        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            int psum = Card.CheckPlayerSum(PlayerHands);

            Card dcard = DeckOfCards[Card.RMethod(DeckOfCards.Count)];

            int dealerHit = DealerHands.Count;

            if (dealerHit == 2)
            {
                Card.CheckSuit(dccLabel, dccLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dccLabel, dccLabel2, dcard, dccPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 3)
            {
                Card.CheckSuit(dcdLabel, dcdLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dcdLabel, dcdLabel2, dcard, dcdPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 4)
            {
                Card.CheckSuit(dceLabel, dceLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dceLabel, dceLabel2, dcard, dcePictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 5)
            {
                Card.CheckSuit(dcfLabel, dcfLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dcfLabel, dcfLabel2, dcard, dcfPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 6)
            {
                Card.CheckSuit(dcgLabel, dcgLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dcgLabel, dcgLabel2, dcard, dcgPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 7)
            {
                Card.CheckSuit(dchLabel, dchLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dchLabel, dchLabel2, dcard, dchPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 8)
            {
                Card.CheckSuit(dciLabel, dciLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dciLabel, dciLabel2, dcard, dciPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 9)
            {
                Card.CheckSuit(dcjLabel, dcjLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dcjLabel, dcjLabel2, dcard, dcjPictureBox);
                DeckOfCards.Remove(dcard);
            }
            else if (dealerHit == 10)
            {
                Card.CheckSuit(dckLabel, dckLabel2, dcard);
                DealerHands.Add(dcard);
                Card.FlipCard(dckLabel, dckLabel2, dcard, dckPictureBox);
                DeckOfCards.Remove(dcard);
            }

            int dsum = Card.CheckDealerSum(DealerHands);

            if (dsum > 21)
            {
                DealerHands = Card.CheckDealerAce(DealerHands);
                dsum = Card.CheckDealerSum(DealerHands);

                if (dsum > 21)
                {
                    Card.Win(displayTextLabel);
                    continueButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    pWin++;
                    games = Card.CalcTotalGames(pWin, dWin, pWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }
            }
            else if (dsum > 16)
            {
                if (dsum < psum)
                {
                    Card.Win(displayTextLabel);
                    continueButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    pWin++;
                    games = Card.CalcTotalGames(pWin, dWin, pWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }
                else if (dsum > psum)
                {
                    Card.Lose(displayTextLabel);
                    continueButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    dWin++;
                    games = Card.CalcTotalGames(dWin, pWin, dWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }
                else if (dsum == psum)
                {
                    Card.Lose(displayTextLabel);
                    continueButton.Visible = false;
                    newGameToolStripMenuItem.Enabled = true;

                    dWin++;
                    games = Card.CalcTotalGames(dWin, pWin, dWinsLabel);
                    Card.DisplayWinPercent(pWin, games, winPercentLabel);
                }
            }
        }

        private void NewGameToolStripMenuItem_Click(object sender, EventArgs e)
        {

            foreach (Card DealerHand in DealerHands)
            {
                if (DealerHand.value == 1)
                {
                    DealerHand.value = 11;
                }
            }

            foreach (Card PlayerHand in PlayerHands)
            {
                if (PlayerHand.value == 1)
                {
                    PlayerHand.value = 11;
                    
                }
            }

            while (PlayerHands.Count > 0)
            {
                DeckOfCards.Add(PlayerHands[0]);
                PlayerHands.Remove(PlayerHands[0]);
            }

            while(DealerHands.Count > 0)
            {
                DeckOfCards.Add(DealerHands[0]);
                DealerHands.Remove(DealerHands[0]);
            }

            dcoPictureBox.Visible = false;
            dcaPictureBox.Visible = false;
            dcaLabel.Visible = false;
            dcaLabel2.Visible = false;
            dcbPictureBox.Visible = false;
            dcbLabel.Visible = false;
            dcbLabel2.Visible = false;
            dccPictureBox.Visible = false;
            dccLabel.Visible = false;
            dccLabel2.Visible = false;
            dcdPictureBox.Visible = false;
            dcdLabel.Visible = false;
            dcdLabel2.Visible = false;
            dcePictureBox.Visible = false;
            dceLabel.Visible = false;
            dceLabel2.Visible = false;
            dcfPictureBox.Visible = false;
            dcfLabel.Visible = false;
            dcfLabel2.Visible = false;
            dcgPictureBox.Visible = false;
            dcgLabel.Visible = false;
            dcgLabel2.Visible = false;
            dchPictureBox.Visible = false;
            dchLabel.Visible = false;
            dchLabel2.Visible = false;
            dciPictureBox.Visible = false;
            dciLabel.Visible = false;
            dciLabel2.Visible = false;
            dcjPictureBox.Visible = false;
            dcjLabel.Visible = false;
            dcjLabel2.Visible = false;
            dckPictureBox.Visible = false;
            dckLabel.Visible = false;
            dckLabel2.Visible = false;

            pcaPictureBox.Visible = false;
            pcaLabel.Visible = false;
            pcaLabel2.Visible = false;
            pcbPictureBox.Visible = false;
            pcbLabel.Visible = false;
            pcbLabel2.Visible = false;
            pccPictureBox.Visible = false;
            pccLabel.Visible = false;
            pccLabel2.Visible = false;
            pcdPictureBox.Visible = false;
            pcdLabel.Visible = false;
            pcdLabel2.Visible = false;
            pcePictureBox.Visible = false;
            pceLabel.Visible = false;
            pceLabel2.Visible = false;
            pcfPictureBox.Visible = false;
            pcfLabel.Visible = false;
            pcfLabel2.Visible = false;
            pcgPictureBox.Visible = false;
            pcgLabel.Visible = false;
            pcgLabel2.Visible = false;
            pchPictureBox.Visible = false;
            pchLabel.Visible = false;
            pchLabel2.Visible = false;
            pciPictureBox.Visible = false;
            pciLabel.Visible = false;
            pciLabel2.Visible = false;
            pcjPictureBox.Visible = false;
            pcjLabel.Visible = false;
            pcjLabel2.Visible = false;
            pckPictureBox.Visible = false;
            pckLabel.Visible = false;
            pckLabel2.Visible = false;

            dcaLabel.ForeColor = Color.Maroon;
            dcaLabel2.ForeColor = Color.Maroon;
            dcbLabel.ForeColor = Color.Maroon;
            dcbLabel2.ForeColor = Color.Maroon;
            dccLabel.ForeColor = Color.Maroon;
            dccLabel2.ForeColor = Color.Maroon;
            dcdLabel.ForeColor = Color.Maroon;
            dcdLabel2.ForeColor = Color.Maroon;
            dceLabel.ForeColor = Color.Maroon;
            dceLabel2.ForeColor = Color.Maroon;
            dcfLabel.ForeColor = Color.Maroon;
            dcfLabel2.ForeColor = Color.Maroon;
            dcgLabel.ForeColor = Color.Maroon;
            dcgLabel2.ForeColor = Color.Maroon;
            dchLabel.ForeColor = Color.Maroon;
            dchLabel2.ForeColor = Color.Maroon;
            dciLabel.ForeColor = Color.Maroon;
            dciLabel2.ForeColor = Color.Maroon;
            dcjLabel.ForeColor = Color.Maroon;
            dcjLabel2.ForeColor = Color.Maroon;
            dckLabel.ForeColor = Color.Maroon;
            dckLabel2.ForeColor = Color.Maroon;

            pcaLabel.ForeColor = Color.Maroon;
            pcaLabel2.ForeColor = Color.Maroon;
            pcbLabel.ForeColor = Color.Maroon;
            pcbLabel2.ForeColor = Color.Maroon;
            pccLabel.ForeColor = Color.Maroon;
            pccLabel2.ForeColor = Color.Maroon;
            pcdLabel.ForeColor = Color.Maroon;
            pcdLabel2.ForeColor = Color.Maroon;
            pceLabel.ForeColor = Color.Maroon;
            pceLabel2.ForeColor = Color.Maroon;
            pcfLabel.ForeColor = Color.Maroon;
            pcfLabel2.ForeColor = Color.Maroon;
            pcgLabel.ForeColor = Color.Maroon;
            pcgLabel2.ForeColor = Color.Maroon;
            pchLabel.ForeColor = Color.Maroon;
            pchLabel2.ForeColor = Color.Maroon;
            pciLabel.ForeColor = Color.Maroon;
            pciLabel2.ForeColor = Color.Maroon;
            pcjLabel.ForeColor = Color.Maroon;
            pcjLabel2.ForeColor = Color.Maroon;
            pckLabel.ForeColor = Color.Maroon;
            pckLabel2.ForeColor = Color.Maroon;

            displayTextLabel.Visible = false;
            dealButton.Visible = true;
            newGameToolStripMenuItem.Enabled = false;
        }
    }
}


//I would like to Update my program with the following:
//keybindings (arrow keys and 0)
//top ten high scores save and view
//gambling